/// <reference types="react-scripts" />
declare module 'deck.gl';
